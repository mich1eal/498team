1. In all scripts, change the command setwd to your working directory 

2. For klar_svm.R, ensure that the svm binaries are in your working directory


(Thanks for your patience, I'll try to get a better handle on how R works for future submissions and require less work for TAs)