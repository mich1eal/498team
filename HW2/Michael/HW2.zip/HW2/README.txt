Change the working directory specified in line 4. 

Requires the caret package installed. 

Make sure a file containing all data exists as specified in line 5. I will include it in the zipped submission. 